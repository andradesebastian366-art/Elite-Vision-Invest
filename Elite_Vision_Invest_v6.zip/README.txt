Elite Vision Invest Angola — Site Oficial

📦 Conteúdo do pacote:
- index.html → Página principal do site
- netlify.toml → Configuração automática para Netlify
- README.txt → Este ficheiro

🌐 Instruções para publicação no Netlify:
1. Aceda a https://www.netlify.com
2. Faça login (ou crie uma conta gratuita)
3. Clique em "Add new site" → "Deploy manually"
4. Arraste este ficheiro ZIP para a janela do Netlify
5. Após o upload, o site será publicado automaticamente em:
   https://elitevisioninvest.netlify.app

👑 Elite Vision Invest Angola — Formação e Consultoria
